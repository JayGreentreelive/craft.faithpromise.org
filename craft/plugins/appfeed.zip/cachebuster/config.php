<?php

return array(
	'assetManifest' => false,
	'assetPrefix'   => false,
	'queryString'   => false
);