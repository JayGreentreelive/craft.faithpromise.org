<?php
namespace Craft;

class AtomFeedMeDataType extends XmlFeedMeDataType
{
    // Same as XML data type.
} 