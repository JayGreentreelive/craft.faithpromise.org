<?php
namespace Craft;

class RssFeedMeDataType extends XmlFeedMeDataType
{
    // Same as XML data type.
} 