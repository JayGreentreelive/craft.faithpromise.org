/**
 * FastCGI Cache Bust plugin for Craft CMS
 *
 * FastCGI Cache Bust JS
 *
 * @author    nystudio107
 * @copyright Copyright (c) 2017 nystudio107
 * @link      https://nystudio107.com
 * @package   FastcgiCacheBust
 * @since     1.0.0
 */
