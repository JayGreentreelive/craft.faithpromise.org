# Smart Map plugin for Craft CMS

_The smart way to use Google Maps in your Craft site_

## Documentation

All documentation can be found at [doublesecretagency.com](https://www.doublesecretagency.com/plugins/smart-map/docs).

## Requirements

Minimum requirements:
 - Craft 2.0

## Feedback?

You can reach us at <a href="mailto:support@doublesecretagency.com?subject=Smart%20Map%20Feedback">support@doublesecretagency.com</a>.

All questions, comments, and suggestions are welcome!