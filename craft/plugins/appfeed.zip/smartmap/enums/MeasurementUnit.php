<?php
namespace Craft;

class MeasurementUnit
{
	const Miles      = 'miles';
	const Kilometers = 'kilometers';
}
