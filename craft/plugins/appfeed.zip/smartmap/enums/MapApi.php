<?php
namespace Craft;

class MapApi
{
	const LatLngArray = 'Array containing latitude & longitude';
	const GoogleMaps  = 'Google Maps';
}
