<?php

return [
	'defaults' => [],
	'endpoints' => [],
];
